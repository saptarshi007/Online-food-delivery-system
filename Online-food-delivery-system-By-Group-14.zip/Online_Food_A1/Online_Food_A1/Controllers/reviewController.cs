﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Online_Food_A1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    [Authorize] // This attribute restricts access to authenticated users
    public class reviewController : ControllerBase
    {
        private static List<Review> reviews = new List<Review>();

        // POST /add-review
        [HttpPost]
        [Route("add-review")]
        public string AddReview([FromBody] Review review)
        {
            // You should validate that the authenticated user has a valid order to review
            // If not, return Unauthorized

            // You would typically save the review details to a database
            // For this example, I'll just add it to the list
            reviews.Add(review);
            return "Review added successfully.";
        }

        // GET /get-reviews/{restaurant_id}
        [HttpGet]
        [Route("get-reviews/{restaurant_id}")]
        [AllowAnonymous] // Allow access without authentication
        public List<Review> GetReviews(int restaurant_id)
        {
            var restaurantReviews = reviews.Where(r => r.RestaurantId == restaurant_id).ToList();
            return restaurantReviews;
        }
    }
}