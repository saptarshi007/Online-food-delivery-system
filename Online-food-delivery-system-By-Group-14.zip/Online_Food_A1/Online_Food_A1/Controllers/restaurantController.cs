﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Online_Food_A1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class restaurantController : ControllerBase
    {

        static List<Restaurant> restaurantList = new List<Restaurant>();
        // GET: api/OFDA
        [HttpGet]
        public IEnumerable<Restaurant> Get()
        {
            return restaurantList;
        }

        // GET: api/OFDA/5
        [HttpGet("{id}", Name = "Get")]
        public Restaurant Get(int id)
        {
            return restaurantList.FirstOrDefault(s => s.RestaurantID == id);
        }

        // POST: api/OFDA
        [HttpPost]
        public void Post([FromBody] Restaurant value)
        {
            restaurantList.Add(value);
        }

        // PUT: api/OFDA/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] Restaurant value)
        {
            int i = restaurantList.FindIndex(s => s.RestaurantID == id);

            if(i >= 0)
            {
                restaurantList[i] = value;
            }
        }

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            restaurantList.RemoveAll(s => s.RestaurantID == id);  
        }
    }
}
