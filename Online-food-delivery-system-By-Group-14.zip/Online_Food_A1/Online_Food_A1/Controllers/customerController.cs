﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Online_Food_A1.Controllers
{
    [Authorize] // This attribute restricts access to authenticated users
    public class CustomerController : ControllerBase
    {
        private static List<Customer> customers = new List<Customer>();

        // POST /register-customer
        [HttpPost]
        [Route("register-customer")]
        [AllowAnonymous] // Allow customer registration without authentication
        public string RegisterCustomer([FromBody] Customer customer)
        {
            // You would typically save the customer details to a database
            // For this example, I'll just add it to the list
            customers.Add(customer);
            return "Customer registered successfully.";
        }

        // GET /get-customer/{customer_id}
        [HttpGet]
        [Route("get-customer/{customer_id}")]
        public string GetCustomer(int customer_id)
        {
            // Here, you should validate that the authenticated customer is the same as the requested customer_id
            // If not, return Unauthorized

            var customer = customers.FirstOrDefault(c => c.Id == customer_id);
            if (customer == null)
                return "Customer not found.";

            return customer.ToString();
        }

        // PUT /update-customer/{customer_id}
        [HttpPut]
        [Route("update-customer/{customer_id}")]
        public string UpdateCustomer(int customer_id, [FromBody] Customer updatedCustomer)
        {
            // Here, you should validate that the authenticated customer is the same as the requested customer_id
            // If not, return Unauthorized

            var customer = customers.FirstOrDefault(c => c.Id == customer_id);
            if (customer == null)
                return "Customer not found.";

            // You should add more validation and security checks here
            customer.Name = updatedCustomer.Name;
            customer.Email = updatedCustomer.Email;
            // Update other properties

            return "Customer information updated successfully.";
        }

        // DELETE /delete-customer/{customer_id}
        [HttpDelete]
        [Route("delete-customer/{customer_id}")]
        public string DeleteCustomer(int customer_id)
        {
            // Here, you should validate that the authenticated customer is the same as the requested customer_id
            // If not, return Unauthorized

            var customer = customers.FirstOrDefault(c => c.Id == customer_id);
            if (customer == null)
                return "Customer not found.";

            // You should add more validation and security checks here

            customers.Remove(customer);

            return "Customer account deleted successfully.";
        }
    }
}
