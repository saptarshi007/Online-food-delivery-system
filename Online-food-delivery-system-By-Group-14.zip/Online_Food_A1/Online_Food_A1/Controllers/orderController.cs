﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Online_Food_A1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class orderController : ControllerBase
    {
        private static List<Order> orders = new List<Order>();

        // POST /place-order
        [HttpPost]
        [Route("place-order")]
        public string PlaceOrder([FromBody] Order order)
        {
            // You should validate that the authenticated customer is the same as the customer in the order
            // If not, return Unauthorized

            // You would typically save the order details to a database
            // For this example, I'll just add it to the list
            orders.Add(order);
            return "Order placed successfully.";
        }

        // GET /my-order/{order_id}
        [HttpGet]
        [Route("my-order/{order_id}")]
        public string myOrders(int order_id)
        {
            var order = orders.FirstOrDefault(o => o.Id == order_id);
            if (order == null)
                return "Order not found.";

            // You should validate that the authenticated user is either the customer or the restaurant related to the order
            // If not, return Unauthorized

            return order.ToString();
        }

        // PUT /update-order/{order_id}
        [HttpPut]
        [Route("update-order/{order_id}")]
        public string UpdateOrder(int order_id, [FromBody] OrderStatusUpdate statusUpdate)
        {
            // Here, you should validate that the authenticated user is the restaurant fulfilling the order
            // If not, return Unauthorized

            var order = orders.FirstOrDefault(o => o.Id == order_id);
            if (order == null)
                return "Order not found.";

            // You should add more validation and security checks here
            order.Status = statusUpdate.Status;

            return "Order status updated successfully.";
        }

        // DELETE /delete-order/{order_id}
        [HttpDelete]
        [Route("delete-order/{order_id}")]
        public string DeleteOrder(int order_id)
        {
            var order = orders.FirstOrDefault(o => o.Id == order_id);
            if (order == null)
                return "Order not found.";

            // You should validate that the authenticated user is either the customer or the restaurant related to the order
            // If not, return Unauthorized

            orders.Remove(order);

            return "Order deleted successfully.";
        }
    }
}
