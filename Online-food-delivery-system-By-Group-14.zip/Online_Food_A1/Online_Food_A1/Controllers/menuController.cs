﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Online_Food_A1.Controllers
{
    [Authorize] // This attribute restricts access to authenticated users
    public class menuController : ControllerBase
    {
        private static List<Menu> Menus = new List<Menu>();

        // POST /add-menu-item/{restaurant_id}
        [HttpPost]
        [Route("add-menu-item/{restaurant_id}")]
        public string AddMenu(int restaurant_id, [FromBody] Menu Menu)
        {
            // You should validate that the authenticated user is the owner of the restaurant
            // If not, return Unauthorized

            // You would typically save the menu item details to a database associated with the restaurant
            // For this example, I'll just add it to the list
            Menus.Add(Menu);
            return "Menu item added successfully.";
        }

        // GET /get-menu-item/{item_id}
        [HttpGet]
        [Route("get-menu-item/{item_id}")]
        [AllowAnonymous] // Allow access without authentication
        public string GetMenu(int item_id)
        {
            var Menu = Menus.FirstOrDefault(item => item.Id == item_id);
            if (Menu == null)
                return "Menu item not found.";

            return Menu.ToString();
        }

        // PUT /update-menu-item/{item_id}
        [HttpPut]
        [Route("update-menu-item/{item_id}")]
        public string UpdateMenu(int item_id, [FromBody] Menu updatedMenu)
        {
            // Here, you should validate that the authenticated user is the owner of the restaurant
            // If not, return Unauthorized

            var Menu = Menus.FirstOrDefault(item => item.Id == item_id);
            if (Menu == null)
                return "Menu item not found.";

            // You should add more validation and security checks here
            Menu.Name = updatedMenu.Name;
            Menu.Price = updatedMenu.Price;
            // Update other properties

            return "Menu item updated successfully.";
        }

        // DELETE /delete-menu-item/{item_id}
        [HttpDelete]
        [Route("delete-menu-item/{item_id}")]
        public string DeleteMenu(int item_id)
        {
            // Here, you should validate that the authenticated user is the owner of the restaurant
            // If not, return Unauthorized

            var Menu = Menus.FirstOrDefault(item => item.Id == item_id);
            if (Menu == null)
                return "Menu item not found.";

            // You should add more validation and security checks here

            Menus.Remove(Menu);

            return "Menu item deleted successfully.";
        }
    }
}
