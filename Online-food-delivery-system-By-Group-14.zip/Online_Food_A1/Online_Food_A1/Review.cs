﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Online_Food_A1
{
    public class Review
    {
        public int Id { get; set; }
        public int RestaurantId { get; set; }
        public int OrderId { get; set; }
        public int Rating { get; set; }
        public string Comment { get; set; }
        // Add more properties

        // You can also add relationships to other resources if needed
    }
}
