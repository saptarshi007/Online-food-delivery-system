﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Online_Food_A1
{
    public class Order
    {
        public int Id { get; set; }
        public int CustomerId { get; set; }
        public int RestaurantId { get; set; }
        public string Status { get; set; }
        // Add more properties

        // You can also add relationships to other resources if needed

        public override string ToString()
        {
            return $"ID: {Id}, CustomerID: {CustomerId}, RestaurantID: {RestaurantId}, Status: {Status}";
        }
    }

    public class OrderStatusUpdate
    {
        public string Status { get; set; }
    }
}
